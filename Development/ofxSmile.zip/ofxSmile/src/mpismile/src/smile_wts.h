/*********** File: smile_wts.h ***********
FILE GENERATED FROM MATLAB
In Matlab:
	>> createMPIWeightsCodeCode(datafile,name)
************************************/

#ifndef __smile_wts_H__
#define __smile_wts_H__

//#include "config.h"
#include "featuredata.h"
namespace smile_wts{
	void assignData(FeatureData &d);
};

#endif

