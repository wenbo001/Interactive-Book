/*********** File: ci.h ***********
FILE GENERATED FROM MATLAB
In Matlab:
	>> createMPIWeightsCodeCode(datafile,name)
************************************/

#ifndef __ci_H__
#define __ci_H__

#include "featuredata.h"
namespace ci{
	void assignData(FeatureData &d);
};

#endif

