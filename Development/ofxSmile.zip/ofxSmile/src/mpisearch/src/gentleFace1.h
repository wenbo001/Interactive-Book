/*********** File: gentleFace1.h ***********
FILE GENERATED FROM MATLAB
In Matlab:
	>> createMPIWeightsCodeCode(datafile,name)
************************************/

#ifndef __gentleFace1_H__
#define __gentleFace1_H__

#include "featuredata.h"
namespace gentleFace1{
	void assignData(FeatureData &d);
};

#endif

