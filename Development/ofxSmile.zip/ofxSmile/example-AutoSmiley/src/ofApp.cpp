#include "ofApp.h"


void ofApp::setup()
{
	ofBackground(30,30,30);

    vision.setupCamera(0, 640, 480);
	
	ttf.loadFont("MONACO.TTF", 48);
	ttfSmall.loadFont("MONACO.TTF", 14);

	img.allocate(320, 240, OF_IMAGE_GRAYSCALE);
	
	lastTime = ofGetElapsedTimef() - 10.0;
		
	smilePct = 0.0;
	smoothPct = 0.0;
}


void doSmily()
{

}


void ofApp::update()
{
    vision.update();
	
	img.setFromPixels(vision.gray.getPixels(), vision.gray.width, vision.gray.height, OF_IMAGE_GRAYSCALE);
		
	ofxSmile::getSmile(img, smilePct);
	
	smoothPct *= 0.8;
	smoothPct += MAX(0, smilePct) * 0.2;
	
	if( ofGetElapsedTimef() - lastTime > 2.0 )
    {
		if( smoothPct > 0.50 ){
			doSmily();
			lastTime = ofGetElapsedTimef();
		}
	}
}


void ofApp::draw()
{
	ofSetColor(255);

    //vision.color.draw(0,0);

    unsigned long long now = ofGetElapsedTimef();
	
	if (now - lastTime < 1.0)
    {
		ofSetColor(255, 255, 255, 100);
		ttf.drawString(":)", -50 + img.width/2, 30 + img.height/2);
	}

}


void ofApp::keyPressed(int key)
{

}
